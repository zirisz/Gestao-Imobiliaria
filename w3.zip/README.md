# Gestao-Imobiliaria
Realização de um Trabalho de Grupo para a disciplina de DEAPC, intitulado de "Gestão Imobiliária"

<<<<<<< HEAD
Teste de Interligação   
=======
Objetivos da Aplicação
- o Projeto em questão terá como principal tarefa a gestão e o tratamento de dados de uma grande variedade de informações relativas ao mundo da imobiliária, tais como as transações financeiras e o seu processamento, dados remetentes às demais propriedades do mercado e, também, informações de cada utilizador interessado na compra de um imóvel.


Tipos de Utilizadores
- Os diferentes tipos de utilizadores estarão de acordo com a compra ou a venda de um imóvel exposto no site criado pelo grupo.
- Sendo assim, destacam-se os Inquilinos, os Proprietários dos Imóveis e, adicionalmente, Agentes Imobiliários, que ajudarão na compra das propriedades.
>>>>>>> d4b2db7a64ccc8b5704dbf9401662f8a14fca7d1
